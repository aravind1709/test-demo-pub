#!/bin/bash
rm -rf "$app_path/*"
